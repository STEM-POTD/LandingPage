# STEM-POTD Website

## Overview
A Node.js based website to host a STEM based project of the day
